#ifndef READLINE_H
#define READLINE_H

ssize_t readLine(int fd, char* buffer, long maxBytes);

#endif
